const express = require('express');
const router = express.Router();
const { signupUser } = require('../controllers/userController');

// Route: POST /signup
router.post('/signup', signupUser);

module.exports = router;
