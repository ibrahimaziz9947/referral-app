// Load environment variables
require('dotenv').config();

// Check required environment variables
const requiredEnvVars = ['MONGO_URI', 'JWT_SECRET'];
const missingEnvVars = requiredEnvVars.filter(envVar => !process.env[envVar]);

if (missingEnvVars.length > 0) {
  console.error('Missing required environment variables:', missingEnvVars);
  process.exit(1);
}

const express = require('express');
const mongoose = require('mongoose');
const jwt = require('jsonwebtoken');
const cors = require('cors');
const authRoutes = require('./routes/auth');
const connectDB = require('./databases/db');
const siteSettingRoutes = require('./routes/siteSettingRoutes');
const walletRoutes = require('./routes/wallet');
const taskRoutes = require('./routes/taskRoutes');
const investmentRoutes = require('./routes/investmentRoutes');
const uploadRoutes = require('./routes/uploadRoutes');
const teamRoutes = require('./routes/teamRoutes');
const earningsRoutes = require('./routes/earningsRoutes');
const siteSettingsRoutes = require('./routes/siteSettings');
const adminAnalyticsRoutes = require('./routes/adminAnalyticsRoutes');
const adminWithdrawalRoutes = require('./routes/adminWithdrawalRoutes');
const cron = require('node-cron');
const { processInvestmentReturns } = require('./controllers/investmentController');

const app = express();

// Middleware
app.use(express.json());
app.use(cors({
  origin: ['https://cashczar.site', 'http://localhost:5173'],
  credentials: true,
  methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
  allowedHeaders: ['Content-Type', 'Authorization']
}));

// Serve uploaded files statically
app.use('/uploads', express.static('uploads'));

// Routes
app.use('/api/auth', authRoutes);
app.use('/api/tasks', taskRoutes);
app.use('/api/wallet', walletRoutes);
app.use('/api/investments', investmentRoutes);
app.use('/api/upload', uploadRoutes);
app.use('/api/team', teamRoutes);
app.use('/api/earnings', earningsRoutes);
app.use('/api/settings', siteSettingRoutes); 
app.use('/api/admin/analytics', adminAnalyticsRoutes);
app.use('/api/admin/withdrawals', adminWithdrawalRoutes);

// Test endpoint for JWT verification
app.post('/api/test-token', (req, res) => {
  const { token } = req.body;
  
  if (!token) {
    return res.status(400).json({ message: 'Token is required' });
  }
  
  try {
    console.log('JWT_SECRET:', process.env.JWT_SECRET);
    console.log('Token being verified:', token.substring(0, 20) + '...');
    
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    console.log('Token decoded successfully:', decoded);
    
    res.json({ 
      message: 'Token verified successfully',
      decoded 
    });
  } catch (error) {
    console.error('Token verification error:', error.message);
    res.status(401).json({ 
      message: 'Invalid token',
      error: error.message 
    });
  }
});

// Health check endpoint
app.get('/', (req, res) => {
  res.json({
    status: 'ok',
    message: 'Server is running',
    environment: process.env.NODE_ENV || 'development'
  });
});

// Connect to MongoDB
connectDB().catch(err => {
  console.error('Failed to connect to MongoDB:', err);
  process.exit(1);
});

// --- Scheduled Tasks --- 

// Schedule investment return processing (runs daily at 1:05 AM server time)
// You can change the schedule string and timezone as needed.
// Example: '0 0 * * *' for midnight, '*/5 * * * *' for every 5 minutes
cron.schedule('5 1 * * *', () => { // 5 minutes past 1 AM
  console.log(`[${new Date().toISOString()}] Running scheduled job: processInvestmentReturns`);
  processInvestmentReturns().catch(err => {
    console.error(`[${new Date().toISOString()}] Error running scheduled investment processing:`, err);
  });
}, {
  scheduled: true,
  timezone: "UTC" // IMPORTANT: Set your server's timezone or use UTC
});

console.log('Scheduled investment return processing job for 01:05 AM UTC daily.');

// --- End Scheduled Tasks ---

// Start server
const PORT = process.env.PORT || 8000;
app.listen(PORT, () => {
  console.log(`Server started on http://localhost:${PORT}`);
  console.log('Environment:', process.env.NODE_ENV || 'development');
});

