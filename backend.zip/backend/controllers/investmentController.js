const InvestmentProduct = require('../models/investmentProduct');
const UserInvestment = require('../models/userInvestment');
const User = require('../models/user');
const SiteSetting = require('../models/siteSetting');
const Earning = require('../models/earning');

// Helper function to get commission percentage based on level
const getCommissionRate = async (level) => {
    // Get base referral bonus from settings
    const baseBonusSetting = await SiteSetting.findOne({ key: 'referral_bonus' });
    const baseBonus = baseBonusSetting ? Number(baseBonusSetting.value) : 10; // Default 10%
    
    // Get bonus increment from settings (optional, defaults to 5%)
    const incrementSetting = await SiteSetting.findOne({ key: 'referral_level_bonus_increment' });
    const increment = incrementSetting ? Number(incrementSetting.value) : 5; // Default 5%

    let multiplier = 0;
    switch (level) {
        case 'silver': multiplier = 1; break;
        case 'gold': multiplier = 2; break;
        case 'diamond': multiplier = 3; break;
        case 'platinum': multiplier = 4; break;
        default: multiplier = 0; // Bronze
    }
    
    return baseBonus + (increment * multiplier);
};

// Admin: Create a new investment product
exports.createInvestmentProduct = async (req, res) => {
    try {
        const { name, description, minimumAmount, returnRate, returnPeriod, returnPeriodUnit } = req.body;
        
        const product = new InvestmentProduct({
            name,
            description,
            minimumAmount,
            returnRate,
            returnPeriod,
            returnPeriodUnit,
            createdBy: req.user._id
        });

        await product.save();
        res.status(201).json(product);
    } catch (error) {
        res.status(400).json({ message: error.message });
    }
};

// Admin: Get all investment products
exports.getAllInvestmentProducts = async (req, res) => {
    try {
        const products = await InvestmentProduct.find().populate('createdBy', 'name email');
        res.json(products);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};

// Admin: Update an investment product
exports.updateInvestmentProduct = async (req, res) => {
    try {
        const { name, description, minimumAmount, returnRate, returnPeriod, returnPeriodUnit, status } = req.body;
        const product = await InvestmentProduct.findById(req.params.id);
        
        if (!product) {
            return res.status(404).json({ message: 'Investment product not found' });
        }

        if (name) product.name = name;
        if (description) product.description = description;
        if (minimumAmount) product.minimumAmount = minimumAmount;
        if (returnRate) product.returnRate = returnRate;
        if (returnPeriod) product.returnPeriod = returnPeriod;
        if (returnPeriodUnit) product.returnPeriodUnit = returnPeriodUnit;
        if (status) product.status = status;

        await product.save();
        res.json(product);
    } catch (error) {
        res.status(400).json({ message: error.message });
    }
};

// Admin: Delete an investment product
exports.deleteInvestmentProduct = async (req, res) => {
    try {
        const product = await InvestmentProduct.findById(req.params.id);
        if (!product) {
            return res.status(404).json({ message: 'Investment product not found' });
        }
        await InvestmentProduct.deleteOne({ _id: req.params.id });
        res.json({ message: 'Investment product deleted successfully' });
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};

// User: Invest in a product
exports.investInProduct = async (req, res) => {
    try {
        const productId = req.params.id || req.body.productId;
        const { amount } = req.body;
        const investorId = req.user._id;
        
        if (!productId) {
            return res.status(400).json({ message: 'Product ID is required' });
        }
        
        if (!amount) {
            return res.status(400).json({ message: 'Investment amount is required' });
        }
        
        // Ensure amount is a valid number
        const investmentAmount = Number(amount);
        if (isNaN(investmentAmount) || investmentAmount <= 0) {
            return res.status(400).json({ message: 'Investment amount must be a positive number' });
        }
        
        const product = await InvestmentProduct.findById(productId);
        if (!product) {
            return res.status(404).json({ message: 'Investment product not found' });
        }

        if (product.status !== 'active') {
            return res.status(400).json({ message: 'Investment product is not active' });
        }

        if (investmentAmount < product.minimumAmount) {
            return res.status(400).json({ message: `Minimum investment amount is ${product.minimumAmount}` });
        }

        const investor = await User.findById(investorId);
        if (!investor) {
            return res.status(404).json({ message: 'Investor not found' }); // Should not happen if authenticated
        }
        if (investor.wallet < investmentAmount) {
            return res.status(400).json({ message: 'Insufficient wallet balance' });
        }

        // Deduct investment amount from investor's wallet first
        investor.wallet -= investmentAmount;
        await investor.save();

        // Create and save the investment record
        const investment = new UserInvestment({
            user: investorId,
            investmentProduct: productId,
            amountInvested: investmentAmount,
            currentValue: investmentAmount
        });
        await investment.save();

        // --- Referral Commission Logic (AFTER investment is saved) --- 
        let commissionAmount = 0; // Initialize commission amount
        let referrer = null;

        if (investor.referredBy) {
            referrer = await User.findById(investor.referredBy);
            if (referrer) {
                try {
                    const commissionRate = await getCommissionRate(referrer.referralLevel);
                    commissionAmount = investmentAmount * (commissionRate / 100);

                    if (commissionAmount > 0) {
                        referrer.wallet += commissionAmount;
                        await referrer.save();
                        
                        // Create Earning record now that investment._id exists
                        const commissionEarning = new Earning({
                            user: referrer._id,
                            amount: commissionAmount,
                            source: 'referral',
                            description: `Commission from ${investor.email || 'user'} investment of $${investmentAmount.toFixed(2)}`,
                            status: 'credited',
                            reference: investment._id, // Reference the investment ID
                            referenceModel: 'UserInvestment'
                        });
                        await commissionEarning.save();
                        
                        console.log(`Awarded $${commissionAmount.toFixed(2)} commission to referrer ${referrer.email} (Level: ${referrer.referralLevel})`);
                    }
                } catch (commissionError) {
                    console.error('Error processing referral commission:', commissionError);
                    // Log error but continue
                    commissionAmount = 0; // Reset commission if error occurs
                }
            }
        }
        // --- End Referral Commission Logic --- 

        res.status(201).json({ 
            investment, 
            commissionAwarded: commissionAmount 
        });

    } catch (error) {
        console.error('Error during investInProduct:', error);
        res.status(400).json({ message: error.message || 'Investment failed' });
    }
};

// User: Get their investments
exports.getUserInvestments = async (req, res) => {
    try {
        const investments = await UserInvestment.find({ user: req.user._id })
            .populate('investmentProduct')
            .sort({ createdAt: -1 });
        res.json(investments);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};

// Admin: Get all user investments
exports.getAllUserInvestments = async (req, res) => {
    try {
        const investments = await UserInvestment.find()
            .populate('user', 'name email')
            .populate('investmentProduct')
            .sort({ createdAt: -1 });
        res.json(investments);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};

// User: Withdraw investment
exports.withdrawInvestment = async (req, res) => {
    try {
        const investment = await UserInvestment.findById(req.params.id)
            .populate('investmentProduct')
            .populate('user');

        if (!investment) {
            return res.status(404).json({ message: 'Investment not found' });
        }

        if (investment.user._id.toString() !== req.user._id.toString()) {
            return res.status(403).json({ message: 'Not authorized to withdraw this investment' });
        }

        if (investment.status === 'withdrawn') {
            return res.status(400).json({ message: 'Investment has already been withdrawn' });
        }

        // Update user's wallet
        const user = await User.findById(req.user._id);
        user.wallet += investment.currentValue;
        await user.save();

        // Update investment status
        investment.status = 'withdrawn';
        await investment.save();

        res.json({ message: 'Investment withdrawn successfully', amount: investment.currentValue });
    } catch (error) {
        res.status(400).json({ message: error.message });
    }
};

// System: Process investment returns (to be called by a scheduled job)
exports.processInvestmentReturns = async () => {
    console.log('Starting investment return processing...');
    const startTime = Date.now();
    let processedCount = 0;
    let errorCount = 0;

    try {
        const activeInvestments = await UserInvestment.find({ status: 'active' })
            .populate('investmentProduct')
            .populate('user', 'email wallet'); // Select needed user fields

        console.log(`Found ${activeInvestments.length} active investments to process.`);

        for (const investment of activeInvestments) {
            try {
                // Skip if essential data is missing
                if (!investment.investmentProduct || !investment.user) {
                    console.warn(`Skipping investment ${investment._id}: Missing product or user data.`);
                    errorCount++;
                    continue;
                }

                const product = investment.investmentProduct;
                const user = investment.user;
                const now = new Date();
                const lastReturn = new Date(investment.lastReturnDate);
                
                // Calculate time difference based on return period unit
                let timeDiff;
                switch (product.returnPeriodUnit) {
                    case 'day':
                        timeDiff = (now - lastReturn) / (1000 * 60 * 60 * 24);
                        break;
                    case 'week':
                        timeDiff = (now - lastReturn) / (1000 * 60 * 60 * 24 * 7);
                        break;
                    case 'month':
                        // Approximation, might need more precise month calculation if strictness is required
                        timeDiff = (now.getFullYear() - lastReturn.getFullYear()) * 12 + (now.getMonth() - lastReturn.getMonth());
                        break;
                    default:
                        console.warn(`Skipping investment ${investment._id}: Unknown returnPeriodUnit ${product.returnPeriodUnit}`);
                        errorCount++;
                        continue; 
                }

                // If enough time has passed, process the return
                if (timeDiff >= product.returnPeriod) {
                    // Calculate return based on the original amount invested (simple interest payout)
                    const returnAmount = (investment.amountInvested * product.returnRate) / 100;
                    
                    if (returnAmount <= 0) {
                        console.log(`Skipping investment ${investment._id} for user ${user.email}: Zero or negative return calculated.`);
                        continue; // Skip if return is zero or negative
                    }

                    // Update user's wallet with the return
                    user.wallet += returnAmount;
                    await user.save();

                    // Update the investment's last return date
                    investment.lastReturnDate = now;
                    await investment.save();
                    
                    // Create an Earning record for traceability
                    const returnEarning = new Earning({
                        user: user._id,
                        amount: returnAmount,
                        source: 'investment',
                        description: `Return from investment in ${product.name}`,
                        status: 'credited',
                        reference: investment._id,
                        referenceModel: 'UserInvestment'
                    });
                    await returnEarning.save();

                    console.log(`Processed return of $${returnAmount.toFixed(2)} for investment ${investment._id} (User: ${user.email})`);
                    processedCount++;
                }
            } catch(innerError) {
                console.error(`Error processing individual investment ${investment._id}:`, innerError.message);
                errorCount++;
                // Continue to next investment even if one fails
            }
        }
    } catch (error) {
        console.error('General error during investment return processing:', error.message);
        errorCount++;
    }
    const duration = (Date.now() - startTime) / 1000;
    console.log(`Investment return processing finished in ${duration}s. Processed: ${processedCount}, Errors: ${errorCount}.`);
}; 