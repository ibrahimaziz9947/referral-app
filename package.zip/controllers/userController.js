const User = require('../models/user');

function generateReferralCode() {
  return Math.random().toString(36).substring(2, 8);
}

// Signup User (with referral code)
const signupUser = async (req, res) => {
  const { username, email, password, referralCode } = req.body;

  try {
    const existingUser = await User.findOne({ email });
    if (existingUser) {
      return res.status(400).json({ message: 'Email already exists' });
    }

    const newUser = new User({
      username,
      email,
      password,
      referralCode: generateReferralCode(),
    });

    // Handle referral code
    if (referralCode) {
      const referrer = await User.findOne({ referralCode });
      if (referrer) {
        newUser.referredBy = referrer._id;
      } else {
        return res.status(400).json({ message: 'Invalid referral code' });
      }
    }

    await newUser.save();

    res.status(201).json({
      message: 'User registered successfully',
      yourReferralCode: newUser.referralCode,
    });
  } catch (err) {
    console.error(err.message);
    res.status(500).send('Server error');
  }
};

module.exports = { signupUser };
